package compiler488.ast.expn;

import compiler488.ast.SourceCoord;


/**
 * This is a place holder for literal constants.
 */
public abstract class ConstExpn extends Expn {
	public ConstExpn(SourceCoord sourceCoord) {
		super(sourceCoord);
	}
}
